# CSC 447 Artificial Intelligence 
# Final Project
#
# Omitted as part of submission for CSC 480
# (not ready)
def grid():
    pass
def search():
    pass
def make_path():
    pass
